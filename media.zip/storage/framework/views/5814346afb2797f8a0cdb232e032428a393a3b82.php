<?php $__env->startSection('content'); ?>

<section class="content-header">
<div class="row">
    <div class="col-md-12">
        <div class="panel block">
            <div class="panel-body">
                <h2>Daftar Siswa</h2>
                <ol class="breadcrumb">
                    <li><a href="dashguru"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">User</li>
                </ol>
            </div>
        </div>
    </div>
</div>
</section>

<section class="content">
<div class="row">
        <div class="col-md-12">
            <div class="panel block">
                <div class="panel-body">

                  <table id="mydatatables" class="table table-collapse table-hover table-light table-striped cell-border table-responsive">
                      <thead>
                        <th>id</th>
                        <th>Nama Siswa</th>
                        <th>Email</th>
                        <th>No Hanphone</th>
                        <th>Status</th>
                      </thead>
                      
                      <tbody> 
                      <?php $__currentLoopData = $datasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->nama); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->no_tlp); ?></td>
                        <td><?php echo e($user->status); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
                </div>
            </div>
        </div>
</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout_guru', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>