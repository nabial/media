<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
</section>

    <!-- Main content -->
    <section class="content">
      
    	hallo
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout_guru', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>