<?php $__env->startSection('content'); ?>
<section class="content-header">
<div class="row">
    <div class="col-md-12">
        <div class="panel block">
            <div class="panel-body">
                <h2>Video</h2>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#"></i>Materi</a></li>
                    <li class="active">Video</li>
                </ol>
            </div>
        </div>
    </div>
</div>
</section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-md-12">
          <?php $__currentLoopData = $materivideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title"><i class="fa fa-video-camera"></i> Videoo</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-angle-down"></i>
                </button>
              </div>
            </div>
            
                <video width="400px" height="350px" controls=""> 
                  <source src="<?php echo e(url('video/'.$materi->video)); ?>" type="video/mp4">
                </video>
           
          </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout_guru', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>