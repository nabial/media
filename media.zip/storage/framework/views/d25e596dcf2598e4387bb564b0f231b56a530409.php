<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Indikator</li>
      </ol>
</section>

    <!-- Main content -->
    <section class="content">
      
    	indikatooorr
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>